# DREAM GPU

Independent AI-focused processor research project.

Current milestone: v0.2

Hardware description: SystemVerilog-compatible Verilog RTL.

Simulation: Icarus Verilog.

Development platform: Android Termux.

The processor is an experimental design.
No physical silicon has been manufactured.
